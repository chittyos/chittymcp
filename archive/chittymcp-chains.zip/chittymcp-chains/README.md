# ChittyMCP Chains

Official tool chains, OpenAPI spec, and CI for the ChittyMCP ecosystem.

## Quick Start
- Upload chains to KV:
  wrangler kv:key put --binding=TOOL_CACHE chains:all @chains.json

## Endpoints
- /execute/{server}/{tool}
- /chain/execute
- /chain/run
- /discover/tools
- /registry/search
- /help/token
