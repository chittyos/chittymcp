# ChittyMCP Chains & OpenAPI

Official tool chains and OpenAPI specification for ChittyMCP integration with ChatGPT, Claude, and AI platforms.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![OpenAPI 3.1.0](https://img.shields.io/badge/OpenAPI-3.1.0-green.svg)](https://spec.openapis.org/oas/v3.1.0)

## 🔗 Quick Links

- **OpenAPI Spec**: [openapi.yaml](./openapi.yaml)
- **Chain Definitions**: [chains.json](./chains.json)
- **API Base**: `https://chittymcp.chittycorp-llc.workers.dev`
- **Documentation**: [ChittyOS Docs](https://docs.chitty.cc)

## 📋 Available Chains

| Chain | Tools | Purpose | File |
|-------|-------|---------|------|
| `executive-decision` | 5 | Strategic decision-making workflow | [executive-decision.json](./chains/executive-decision.json) |
| `legal-workflow` | 7 | Legal case and compliance management | [legal-workflow.json](./chains/legal-workflow.json) |
| `infrastructure-deploy` | 4 | Cloudflare infrastructure deployment | [infrastructure-deploy.json](./chains/infrastructure-deploy.json) |
| `cross-sync` | 3 | Device and state synchronization | [cross-sync.json](./chains/cross-sync.json) |
| `full-orchestration` | 19 | Complete ChittyMCP orchestration | [full-orchestration.json](./chains/full-orchestration.json) |

## 🚀 Usage

### ChatGPT Custom GPT

1. Create new Custom GPT in ChatGPT
2. Go to Actions → Import from URL or file
3. Upload `openapi.yaml`
4. Configure authentication: Bearer token
5. Use chains via `/v1/mcp/chains/{chainName}`

### Direct API

```bash
curl -X POST https://chittymcp.chittycorp-llc.workers.dev/v1/mcp/chains/executive-decision \
  -H "Authorization: Bearer $CHITTY_ID_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"context": "...", "parameters": {...}}'
```

## 🔐 Authentication

Get your ChittyID token from `https://id.chitty.cc`

## 📊 Tool Categories

### Executive (5 tools)
- `make_executive_decision`, `delegate_task`, `analyze_performance`, `strategic_planning`, `risk_assessment`

### Legal (7 tools)
- `generate_chitty_id`, `create_legal_case`, `analyze_document`, `process_payment`, `compliance_check`, `search_cases`, `execute_workflow`

### Infrastructure (4 tools)
- `deploy_worker`, `manage_r2_bucket`, `execute_d1_query`, `manage_kv_namespace`

### Cross-Sync (3 tools)
- `register_mcp_server`, `sync_mcp_state`, `get_synced_servers`

### Webhooks (Entity Financial Alerts)
- Register webhooks for balance drops, large transactions, compliance issues

## 📄 License

MIT License - ChittyCorp LLC

---

**Version**: 3.0.0
**Last Updated**: 2025-10-08
**Maintainer**: ChittyOS Team
